chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'getPlaces' || msg.action === 'getActivities') {
    const url = msg.action === 'getPlaces'
      ? `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${msg.lat},${msg.lng}&radius=5000&keyword=pickleball+court&key=${msg.key}`
      : `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(`activities for ${msg.groupSize} people near me`)}&location=${msg.lat},${msg.lng}&radius=5000&key=${msg.key}`;
    fetch(url)
      .then(res => res.json())
      .then(data => sendResponse({ results: data.results }))
      .catch(err => sendResponse({ error: err.toString() }));
    return true;
  }
});
