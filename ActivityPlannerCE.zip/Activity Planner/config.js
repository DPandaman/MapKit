const CONFIG = {
  API_KEY: 'AIzaSyDCdx5DbiVZ3cthq9l63EzQrDk265npm-k'
};
