function initMap() {
  const params = new URLSearchParams(window.location.search);
  const userLoc = {
    lat: parseFloat(params.get('lat')),
    lng: parseFloat(params.get('lng'))
  };
  const map = new google.maps.Map(document.getElementById('map'), {
    center: userLoc,
    zoom: 14
  });
  const service = new google.maps.places.PlacesService(map);
  service.nearbySearch({
    location: userLoc,
    radius: 5000,
    keyword: 'pickleball court'
  }, (results, status) => {
    if (status === google.maps.places.PlacesServiceStatus.OK) {
      results.forEach(place => createMarker(place, map, userLoc));
    } else {
      console.error('Places request failed:', status);
    }
  });
}

function createMarker(place, map, userLoc) {
  const marker = new google.maps.Marker({
    map,
    position: place.geometry.location,
    title: place.name
  });
  const infoWindow = new google.maps.InfoWindow();
  marker.addListener('click', () => {
    const div = document.createElement('div');
    div.className = 'info-window';
    div.innerHTML = `
      <h2>${place.name}</h2>
      <p>Rating: ${place.rating || 'N/A'} (${place.user_ratings_total || 0} reviews)</p>
      <button id="directions-btn">Directions</button>
      <button id="bookmark-btn">Bookmark</button>
    `;
    infoWindow.setContent(div);
    infoWindow.open(map, marker);

    div.querySelector('#directions-btn').addEventListener('click', () => {
      const ds = new google.maps.DirectionsService();
      const dr = new google.maps.DirectionsRenderer();
      dr.setMap(map);
      ds.route({
        origin: userLoc,
        destination: place.geometry.location,
        travelMode: 'DRIVING'
      }, (res, st) => {
        if (st === 'OK') dr.setDirections(res);
        else console.error('Directions error:', st);
      });
    });

    div.querySelector('#bookmark-btn').addEventListener('click', () => {
      chrome.storage.local.get({ bookmarks: [] }, data => {
        const bms = data.bookmarks;
        if (!bms.find(b => b.place_id === place.place_id)) {
          bms.push({
            name: place.name,
            place_id: place.place_id,
            location: place.geometry.location.toJSON()
          });
          chrome.storage.local.set({ bookmarks: bms });
        }
      });
    });
  });
}