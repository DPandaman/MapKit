document.addEventListener('DOMContentLoaded', () => {
  const ul = document.getElementById('bookmark-list');
  chrome.storage.local.get({ bookmarks: [] }, data => {
    data.bookmarks.forEach(b => {
      const li = document.createElement('li');
      li.textContent = b.name;
      const btn = document.createElement('button');
      btn.textContent = 'Show';
      btn.onclick = () => window.open(
        `https://www.google.com/maps/dir/?api=1&destination=${b.loc.lat},${b.loc.lng}`,
        '_blank'
      );
      li.appendChild(btn);
      ul.appendChild(li);
    });
  });
});
