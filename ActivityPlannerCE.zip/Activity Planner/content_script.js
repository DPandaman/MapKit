const API_KEY = CONFIG.API_KEY;

(function () {
  const btn = document.createElement('button');
  btn.id = 'activity-finder-button';
  btn.innerText = '📍';
  btn.title = 'Group Activity Planner';
  document.body.appendChild(btn);
  btn.addEventListener('click', toggleOverlay);

  function toggleOverlay() {
    const existing = document.getElementById('activity-finder-overlay');
    if (existing) {
      existing.remove();
      return;
    }

    const overlay = document.createElement('div');
    overlay.id = 'activity-finder-overlay';

    const controls = document.createElement('div');
    controls.id = 'activity-finder-controls';

    const input = document.createElement('input');
    input.id = 'activity-finder-input';
    input.type = 'number';
    input.min = '1';
    input.placeholder = 'Group size';

    const searchBtn = document.createElement('button');
    searchBtn.id = 'activity-finder-search-btn';
    searchBtn.textContent = 'Find Activities';

    controls.append(input, searchBtn);

    const mapDiv = document.createElement('div');
    mapDiv.id = 'activity-finder-map';

    const listDiv = document.createElement('div');
    listDiv.id = 'activity-finder-list';

    overlay.append(controls, mapDiv, listDiv);
    document.body.appendChild(overlay);

    mapDiv.innerHTML = '<p style="text-align:center;padding:100px 0;color:#666;">Loading courts…</p>';
    listDiv.innerHTML = '';

    navigator.geolocation.getCurrentPosition(
      pos => fetchPlaces(pos.coords.latitude, pos.coords.longitude, mapDiv, listDiv),
      () => mapDiv.innerHTML = '<p style="text-align:center;padding:100px 0;color:#666;">Location unavailable.</p>'
    );

    searchBtn.addEventListener('click', () => {
      const size = parseInt(input.value, 10);
      if (size > 1)
        navigator.geolocation.getCurrentPosition(
          pos => fetchPlaces(pos.coords.latitude, pos.coords.longitude, mapDiv, listDiv, size),
          () => console.error('Location error')
        );
    });
  }

  function fetchPlaces(lat, lng, mapDiv, listDiv, groupSize) {
    const action = groupSize > 1 ? 'getActivities' : 'getPlaces';
    chrome.runtime.sendMessage({ action, lat, lng, key: API_KEY, groupSize },
      res => handleResponse(res, mapDiv, listDiv)
    );
  }

  function handleResponse(response, mapDiv, listDiv) {
    if (chrome.runtime.lastError || !response || response.error) {
      mapDiv.innerHTML = '<p style="text-align:center;padding:100px 0;color:#c00;">Error loading data.</p>';
      return;
    }
    const places = response.results || [];
    if (!places.length) {
      mapDiv.innerHTML = '<p style="text-align:center;padding:100px 0;color:#666;">No results found.</p>';
      return;
    }

    const markers = places.map(p => p.geometry.location.lat + ',' + p.geometry.location.lng).join('|');
    const staticUrl = `https://maps.googleapis.com/maps/api/staticmap?size=420x260&maptype=roadmap&markers=color:red|${markers}&key=${API_KEY}`;
    mapDiv.innerHTML = `<img src="${staticUrl}" style="width:100%;height:260px;object-fit:cover;">`;

    listDiv.innerHTML = '';
    places.forEach(place => {
      const item = document.createElement('div');
      item.innerHTML = `<strong>${place.name}</strong><br>Rating: ${place.rating || 'N/A'} (${place.user_ratings_total || 0})`;

      const dirBtn = document.createElement('button');
      dirBtn.textContent = 'Directions';
      dirBtn.onclick = () => window.open(
        `https://www.google.com/maps/dir/?api=1&destination=${place.geometry.location.lat},${place.geometry.location.lng}`,
        '_blank'
      );

      const bmBtn = document.createElement('button');
      bmBtn.textContent = 'Bookmark';
      bmBtn.onclick = () => chrome.storage.local.get({ bookmarks: [] }, data => {
        const b = data.bookmarks;
        if (!b.find(x => x.place_id === place.place_id)) {
          b.push({ place_id: place.place_id, name: place.name, loc: place.geometry.location });
          chrome.storage.local.set({ bookmarks: b });
        }
      });

      item.append(dirBtn, bmBtn);
      listDiv.appendChild(item);
    });
  }
})();
