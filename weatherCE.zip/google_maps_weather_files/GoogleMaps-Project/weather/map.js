const map = L.map('map').setView([37.8, -96], 5);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors'
}).addTo(map);

let weatherLayer = null;

function clearLayer() {
  if (weatherLayer) {
    map.removeLayer(weatherLayer);
    weatherLayer = null;
  }
}

function loadLayer(layerName) {
  clearLayer();
  const tileURL = `https://tile.openweathermap.org/map/${layerName}/{z}/{x}/{y}.png?appid=${apiKey}`;
  weatherLayer = L.tileLayer(tileURL, { opacity: 0.8 });
  weatherLayer.addTo(map);
}

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const selected = tab.getAttribute('data-layer');
    loadLayer(selected);
  });
});

loadLayer('wind_new');